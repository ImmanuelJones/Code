const platforms = ["Instagram","Facebook","WhatsApp","X / Twitter","Snapchat","YouTube","Telegram","LinkedIn","TikTok","Other"];
const types = [
  {k:"bullying", t:"Cyberbullying / Harassment", d:"Repeated hostile messages, mockery, or pile-ons directed at you"},
  {k:"fake", t:"Fake or Impersonation Account", d:"Someone created a profile pretending to be you"},
  {k:"deepfake", t:"Deepfake / AI-generated Impersonation", d:"AI-generated images, audio, or video misrepresenting you"},
  {k:"threat", t:"Threats or Blackmail", d:"Direct threats of harm, or coercion using private material"},
  {k:"ncii", t:"Unauthorized Sharing of Private Content", d:"Private images or messages shared without your consent"},
  {k:"doxx", t:"Doxxing / Privacy Violation", d:"Personal details like address or phone number posted publicly"},
  {k:"other", t:"Other", d:"Something not listed above"}
];
const evidenceTypes = ["Screenshots","Links / URLs","Chat or message logs","Video or audio recordings","Account/profile info of the other party"];
const wbStatements = [
  "I feel physically safe right now",
  "I have someone I trust I can talk to about this",
  "This is affecting my sleep or daily routine",
  "I've felt overwhelmed or hopeless because of this",
  "I would like to talk to someone about how I'm feeling"
];
const steps = ["platform","type","details","evidence","wellbeing","review"];
const stepLabels = ["Platform","Type","Details","Evidence","Wellbeing","Review"];

let data = { platform:null, otherPlatform:"", types:[], date:"", frequency:"", perpetrator:"", description:"", evidence:[], evidenceNotes:"", wellbeing:[] };

function showView(id){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  document.getElementById("view-"+id).classList.add("active");
  window.scrollTo({top:0, behavior:"smooth"});
  if(id==="review") renderReview();
  buildAllSteppers();
}

function buildStepper(container, activeStep){
  container.innerHTML = "";
  steps.forEach((s,i)=>{
    const dot = document.createElement("div");
    const idx = i+1;
    dot.className = "step-dot " + (idx < activeStep ? "done" : idx===activeStep ? "current" : "");
    dot.textContent = idx;
    dot.title = stepLabels[i];
    container.appendChild(dot);
    if(i < steps.length-1){
      const track = document.createElement("div");
      track.className = "step-track " + (idx < activeStep ? "done" : "");
      container.appendChild(track);
    }
  });
}
function buildAllSteppers(){
  const ids = ["stepper","stepper2","stepper3","stepper4","stepper5","stepper6"];
  ids.forEach((id,i)=>{
    const el = document.getElementById(id);
    if(el) buildStepper(el, i+1);
  });
}

// Platform grid
const platformGrid = document.getElementById("platformGrid");
platforms.forEach(p=>{
  const d = document.createElement("div");
  d.className = "choice"; d.textContent = p;
  d.onclick = ()=>{
    document.querySelectorAll("#platformGrid .choice").forEach(c=>c.classList.remove("selected"));
    d.classList.add("selected");
    data.platform = p;
    document.getElementById("otherPlatformField").style.display = p==="Other" ? "block" : "none";
    document.getElementById("platformNext").disabled = false;
  };
  platformGrid.appendChild(d);
});

// Type list
const typeList = document.getElementById("typeList");
types.forEach(ty=>{
  const row = document.createElement("label");
  row.className = "type-row";
  row.innerHTML = `<input type="checkbox" value="${ty.k}"><div class="t-body"><b>${ty.t}</b><span>${ty.d}</span></div>`;
  row.querySelector("input").addEventListener("change", e=>{
    row.classList.toggle("selected", e.target.checked);
    data.types = Array.from(document.querySelectorAll("#typeList input:checked")).map(i=>i.value);
    document.getElementById("typeNext").disabled = data.types.length===0;
  });
  typeList.appendChild(row);
});

// Evidence grid
const evidenceGrid = document.getElementById("evidenceGrid");
evidenceTypes.forEach(ev=>{
  const row = document.createElement("label");
  row.className = "check-row";
  row.innerHTML = `<input type="checkbox" value="${ev}"><span>${ev}</span>`;
  row.querySelector("input").addEventListener("change", ()=>{
    data.evidence = Array.from(document.querySelectorAll("#evidenceGrid input:checked")).map(i=>i.value);
  });
  evidenceGrid.appendChild(row);
});

// Wellbeing grid
const wbGrid = document.getElementById("wbGrid");
wbStatements.forEach((s,i)=>{
  const row = document.createElement("label");
  row.className = "check-row";
  row.innerHTML = `<input type="checkbox" data-idx="${i}"><span>${s}</span>`;
  row.querySelector("input").addEventListener("change", updateWellbeing);
  wbGrid.appendChild(row);
});
function updateWellbeing(){
  const checked = Array.from(document.querySelectorAll("#wbGrid input:checked")).map(i=>parseInt(i.dataset.idx));
  data.wellbeing = checked.map(i=>wbStatements[i]);
  const result = document.getElementById("wbResult");
  const flagged = checked.includes(2) || checked.includes(3) || checked.includes(4);
  if(checked.length===0){ result.classList.remove("show"); return; }
  result.classList.add("show");
  if(flagged){
    result.className = "wb-result show wb-flag";
    result.innerHTML = "<strong>It sounds like this has been weighing on you.</strong> That's a reasonable response to what you've been through. Consider reaching out to iCall or KIRAN on the resources page — talking to someone trained to help can make a real difference.";
  } else {
    result.className = "wb-result show wb-ok";
    result.innerHTML = "Thanks for checking in with yourself. The support resources are still there on the next page if that ever changes.";
  }
}

// Collect free-text fields on continue
document.getElementById("view-details").addEventListener("click", ()=>{
  data.date = document.getElementById("incidentDate").value;
  const freq = document.querySelector('input[name="frequency"]:checked');
  data.frequency = freq ? freq.value : "";
  data.perpetrator = document.getElementById("perpetrator").value;
  data.description = document.getElementById("description").value;
  data.otherPlatform = document.getElementById("otherPlatform").value;
}, true);
document.getElementById("view-evidence").addEventListener("click", ()=>{
  data.evidenceNotes = document.getElementById("evidenceNotes").value;
}, true);

function escapeHtml(value){
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderReview(){
  const platformShown = data.platform === "Other"
    ? (data.otherPlatform || "Other")
    : (data.platform || "—");

  const typeLabels = data.types
    .map(k => types.find(t => t.k === k)?.t)
    .filter(Boolean);

  const wb = data.wellbeing.length
    ? data.wellbeing.map(w => `<span class="tag">${escapeHtml(w)}</span>`).join(" ")
    : "<span style='color:var(--ink-soft)'>Skipped</span>";

  document.getElementById("reviewContent").innerHTML = `
    <div class="summary-block">
      <h3>Platform</h3>
      <dl><dt>Where</dt><dd>${escapeHtml(platformShown)}</dd></dl>
    </div>

    <div class="summary-block">
      <h3>Incident type</h3>
      <dl>
        ${typeLabels.map(t => `<dt></dt><dd><span class="tag">${escapeHtml(t)}</span></dd>`).join("") || "<dt>—</dt><dd>None selected</dd>"}
      </dl>
    </div>

    <div class="summary-block">
      <h3>Details</h3>
      <dl>
        <dt>Date</dt><dd>${escapeHtml(data.date || "Not specified")}</dd>
        <dt>Frequency</dt><dd>${escapeHtml(data.frequency || "Not specified")}</dd>
        <dt>Account involved</dt><dd>${escapeHtml(data.perpetrator || "Not specified")}</dd>
        <dt>Description</dt><dd>${escapeHtml(data.description || "Not provided")}</dd>
      </dl>
    </div>

    <div class="summary-block">
      <h3>Evidence</h3>
      <dl>
        <dt>Types held</dt><dd>${escapeHtml(data.evidence.join(", ") || "None specified")}</dd>
        <dt>Stored at</dt><dd>${escapeHtml(data.evidenceNotes || "Not specified")}</dd>
      </dl>
    </div>

    <div class="summary-block">
      <h3>Wellbeing check-in</h3>
      <dl><dt>Noted</dt><dd>${wb}</dd></dl>
    </div>

    <div class="summary-block">
      <dl><dt>Generated</dt><dd>${escapeHtml(new Date().toLocaleString())}</dd></dl>
    </div>
  `;
}

buildAllSteppers();
