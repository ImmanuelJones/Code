# System Architecture

## High-Level Flow

```text
User
  ↓
React Frontend
  ↓ HTTPS / REST API
Django REST Framework
  ↓
Application Modules
  ├── Users
  ├── Incidents
  ├── Evidence
  ├── Wellbeing Assessments
  ├── Reports
  └── Official Resources
  ↓
PostgreSQL
  ↓
Secure Evidence Storage
```

## Module Responsibilities

### Frontend
Handles navigation, accessible forms, client-side validation, incident review, report preview, and resource navigation.

### Backend
Handles authentication, server-side validation, authorization, incident persistence, evidence metadata, assessment scoring, report generation, and security controls.

### Database
Stores structured records for users, incidents, assessments, reports, and evidence metadata.

### File Storage
Stores uploaded evidence separately from relational records. Access should be restricted to the authorized owner/workflow and protected against direct public access.

## Security Model

1. Validate every field on the server.
2. Treat uploaded files as untrusted input.
3. Restrict file types, file size, and storage paths.
4. Use access controls for reports and evidence.
5. Never expose secrets or API keys in the frontend repository.
6. Apply rate limits to forms, authentication, uploads, and report generation.
7. Log security-relevant events without unnecessarily logging sensitive evidence contents.
8. Define a deletion and retention policy before production deployment.

## API Sketch

```text
POST   /api/incidents/
GET    /api/incidents/{id}/
POST   /api/incidents/{id}/evidence/
POST   /api/incidents/{id}/assessment/
POST   /api/incidents/{id}/report/
GET    /api/resources/
```

Exact endpoints will be finalized during implementation.

## Report Pipeline

```text
Incident Data
     ↓
Validation
     ↓
Report Template
     ↓
PDF / DOCX Generator
     ↓
User Review
     ↓
Download / Print
```

Reports must clearly identify themselves as user-generated summaries rather than official complaints.
