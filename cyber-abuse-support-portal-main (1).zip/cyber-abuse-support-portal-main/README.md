# Cyber Abuse Support Portal

> A secure web-based support and incident documentation platform for victims of cyberbullying, online impersonation, deepfakes, and AI-generated identity abuse.

## Project Overview

The Cyber Abuse Support Portal is designed to help people who are harmed by online abuse document an incident, preserve relevant details, understand its potential impact on their wellbeing, generate a structured incident summary, and reach official cybercrime reporting resources.

The project is intentionally designed as a **support and documentation tool**, not as a replacement for police investigation, cyber-forensics, legal advice, or professional mental-health care.

## Problem Statement

The growth of social media, generative AI, deepfake technology, and online impersonation creates new forms of digital harm. Victims may struggle to organize evidence, understand what information to report, or find the appropriate official reporting channel.

This project aims to provide a single, user-friendly workflow for:

- Cyberbullying and online harassment
- Fake accounts and impersonation
- Deepfake and AI-generated images/videos
- Threats and blackmail
- Unauthorized sharing of private content
- Account compromise and related abuse

## Core Workflow

```text
Victim
  ↓
Landing Page
  ↓
Incident Assessment
  ↓
Platform + Incident Type
  ↓
Incident Details + Evidence Metadata
  ↓
Optional Digital-Abuse Wellbeing Check
  ↓
Review Incident Summary
  ↓
Generate PDF / DOCX Report
  ↓
Official Cybercrime / Maharashtra Cyber Resources
```

## Key Features

### 1. Victim Information
Collect only the minimum information necessary for the workflow, such as age group, state/district, and optional contact information.

### 2. Incident Classification
Users can select one or more categories:

- Cyberbullying
- Online harassment
- Fake account / impersonation
- Deepfake
- AI-generated image/video
- Threats
- Blackmail/extortion
- Unauthorized sharing of private content
- Account hacking/compromise
- Other

### 3. Social Media Platforms
Initial platform choices may include:

- WhatsApp
- Instagram
- Snapchat
- YouTube
- Facebook
- Other

### 4. Evidence Documentation
The portal can record:

- Content/account URL
- Username or account identifier
- Platform
- Date and time
- Incident description
- Evidence metadata
- Optional screenshot or document upload

Original evidence should not be altered. The application should encourage users to preserve original messages, screenshots, URLs, and files where possible.

### 5. Digital-Abuse Wellbeing Check
An optional, non-diagnostic questionnaire can ask whether the incident is affecting areas such as:

- Sleep
- Concentration
- Studies/work
- Sense of safety
- Stress/anxiety
- Social interaction

The result must be described as a **wellbeing screening result, not a medical diagnosis**.

### 6. Incident Report Generation
Generate a structured user-reviewable report in:

- PDF
- DOCX
- Print-friendly web view

The report should clearly state that it is a **user-generated incident summary and not an official police complaint or FIR**.

### 7. Official Reporting Resources
After completing the workflow, users can be directed to the official Indian cybercrime reporting resources and Maharashtra Cyber resources.

> Official links and reporting instructions should be verified and maintained before production deployment.

## Recommended Technology Stack

| Layer | Technology |
|---|---|
| Frontend | React.js |
| UI | Bootstrap or Tailwind CSS |
| Backend | Python + Django |
| API | Django REST Framework |
| Database | PostgreSQL |
| Authentication | Django Authentication / secure session management |
| PDF generation | ReportLab |
| DOCX generation | python-docx |
| AI/ML experimentation | Python + PyTorch/OpenCV |
| Version control | Git + GitHub |
| Deployment | Render, Railway, AWS, or equivalent |

## Proposed Architecture

```text
┌───────────────────────────────┐
│          Web Browser          │
│     React / HTML / CSS / JS   │
└───────────────┬───────────────┘
                │ HTTPS / REST API
                ▼
┌───────────────────────────────┐
│          Django API           │
├──────────────┬────────────────┤
│ Incidents    │ Assessments    │
│ Evidence     │ Reports        │
│ Resources    │ Authentication │
└──────────────┬────────────────┘
               │
               ▼
┌───────────────────────────────┐
│          PostgreSQL            │
└───────────────────────────────┘
               │
               ▼
┌───────────────────────────────┐
│ Secure File/Object Storage    │
└───────────────────────────────┘
```

## Database Model

### Users

```text
user_id
name / optional identifier
age_group
state
district
created_at
```

### Incidents

```text
incident_id
user_id
platform
incident_type
incident_date
content_url
description
status
created_at
```

### Evidence

```text
evidence_id
incident_id
file_name
file_type
file_hash
uploaded_at
```

### Wellbeing Assessments

```text
assessment_id
user_id
incident_id
score
assessment_date
```

### Reports

```text
report_id
incident_id
report_number
generated_at
```

## Security & Privacy Requirements

Because the portal may process highly sensitive information, privacy and security are first-class requirements.

The implementation should include, as appropriate:

- HTTPS/TLS
- Strong authentication and session controls
- Password hashing
- CSRF protection
- XSS protection
- SQL injection prevention through safe ORM/API practices
- Strict input validation
- File type and file size validation
- Access control
- Secure evidence storage
- Encryption of sensitive data where appropriate
- Audit logging
- Rate limiting and abuse prevention
- A documented data-retention/deletion policy
- Minimal collection of personally identifiable information

The project should avoid collecting sensitive data that is not necessary for the stated purpose.

## Important Scope Boundaries

### The system should NOT:

- Diagnose mental-health conditions
- Replace a qualified mental-health professional
- Claim that an AI detector proves content is a deepfake
- Automatically file a police complaint without an authorized official integration
- Present a generated PDF/DOCX as an FIR or official government complaint
- Encourage confrontation with the suspected offender

## Future AI/ML Module

An experimental deepfake-analysis module may be added later using Python, OpenCV, PyTorch, or another suitable ML framework.

Potential workflow:

```text
Uploaded Media
      ↓
Pre-processing
      ↓
Feature Extraction / Model Inference
      ↓
Risk / Confidence Indicator
      ↓
Human-readable explanation
```

Any model output must be presented as **experimental assistance**, not forensic proof. False positives and false negatives are possible.

## Development Roadmap

### Phase 1 — MVP

- Landing page
- Incident form
- Platform selection
- Incident classification
- Evidence metadata
- Wellbeing screening
- Report preview
- PDF/DOCX generation
- Official resource links

### Phase 2 — Platform & Account Features

- User accounts
- Secure dashboard
- Report history
- Evidence uploads
- Unique report IDs
- Multilingual interface: English / Hindi / Marathi
- Email notifications where appropriate

### Phase 3 — Advanced Capabilities

- Evidence integrity hashes
- Secure object storage
- Analytics dashboard
- Recommendation engine for next steps
- Experimental deepfake/AI-media analysis
- Accessibility improvements
- Security testing and deployment hardening

## Suggested Project Structure

```text
cyber-abuse-support-portal/
├── frontend/
│   ├── pages/
│   ├── components/
│   └── services/
├── backend/
│   ├── users/
│   ├── incidents/
│   ├── evidence/
│   ├── assessments/
│   ├── reports/
│   └── resources/
├── database/
├── documentation/
├── README.md
├── ARCHITECTURE.md
├── ROADMAP.md
└── .gitignore
```

## Project Status

**Status:** Planning / MVP architecture

This repository currently documents the proposed product, architecture, security considerations, and development roadmap. Implementation will be developed incrementally.

## Responsible Use

This project is intended for education, community support, and software-development experimentation. Before production use, the system requires appropriate legal, privacy, security, accessibility, and mental-health review.

## License

License to be selected when implementation begins.
