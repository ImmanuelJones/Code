# Development Roadmap

## Phase 1 — MVP

- [ ] React frontend setup
- [ ] Django backend setup
- [ ] PostgreSQL integration
- [ ] Incident intake form
- [ ] Platform selection
- [ ] Incident classification
- [ ] Evidence metadata capture
- [ ] Optional wellbeing screening
- [ ] Incident review page
- [ ] PDF report generation
- [ ] DOCX report generation
- [ ] Print-friendly report
- [ ] Official reporting-resource page

## Phase 2 — Security & Account Features

- [ ] Secure user authentication
- [ ] User dashboard
- [ ] Report history
- [ ] Controlled evidence uploads
- [ ] Unique incident/report IDs
- [ ] Server-side validation
- [ ] Rate limiting
- [ ] Audit logging
- [ ] Data retention/deletion controls
- [ ] English / Hindi / Marathi support
- [ ] Accessibility review

## Phase 3 — Advanced Features

- [ ] Evidence integrity hashes
- [ ] Secure object storage
- [ ] Admin/moderator tooling
- [ ] Analytics dashboard
- [ ] Next-step recommendation engine
- [ ] Experimental AI/deepfake analysis
- [ ] Automated testing and CI
- [ ] Production security review

## Non-Goals

- [ ] Medical diagnosis
- [ ] Replacing professional mental-health care
- [ ] Automated legal conclusions
- [ ] Claiming AI-generated content analysis is forensic proof
- [ ] Automatic filing of official complaints without an authorized integration
